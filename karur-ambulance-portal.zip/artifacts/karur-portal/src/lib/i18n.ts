export type Language = 'en' | 'ta';

type Translations = {
  [key: string]: {
    en: string;
    ta: string;
  };
};

export const translations: Translations = {
  "Start Emergency": { en: "Start Emergency", ta: "அவசரநிலை தொடங்கு" },
  "Stop Emergency": { en: "Stop Emergency", ta: "அவசரநிலை நிறுத்து" },
  "Start Duty": { en: "Start Duty", ta: "பணி தொடங்கு" },
  "End Duty": { en: "End Duty", ta: "பணி முடி" },
  "Go Online": { en: "Go Online", ta: "ஆன்லைனில் செல்" },
  "Go Offline": { en: "Go Offline", ta: "ஆஃப்லைனில் செல்" },
  "Emergency Alert": { en: "Emergency Alert", ta: "அவசர எச்சரிக்கை" },
  "Ambulance Nearby": { en: "Ambulance Nearby", ta: "ஆம்புலன்ஸ் அருகில் உள்ளது" },
  "Please clear the road": { en: "Please clear the road", ta: "தயவுசெய்து வழி விடுங்கள்" },
  "Driver Name": { en: "Driver Name", ta: "வாகன ஓட்டுனர் பெயர்" },
  "Ambulance Number": { en: "Ambulance Number", ta: "ஆம்புலன்ஸ் எண்" },
  "Login": { en: "Login", ta: "உள்நுழைவு" },
  "Register": { en: "Register", ta: "பதிவு செய்" },
  "Logout": { en: "Logout", ta: "வெளியேறு" },
  "Dashboard": { en: "Dashboard", ta: "டாஷ்போர்டு" },
  "Notification History": { en: "Notification History", ta: "அறிவிப்பு வரலாறு" },
  "Alert History": { en: "Alert History", ta: "எச்சரிக்கை வரலாறு" },
  "Nearby Users": { en: "Nearby Users", ta: "அருகில் உள்ள பயனர்கள்" },
  "Distance": { en: "Distance", ta: "தூரம்" },
  "Last Update": { en: "Last Update", ta: "கடைசி புதுப்பிப்பு" },
  "Status": { en: "Status", ta: "நிலை" },
  "Active": { en: "Active", ta: "செயல்பாட்டில்" },
  "Inactive": { en: "Inactive", ta: "செயல்படவில்லை" },
  "On Duty": { en: "On Duty", ta: "பணியில்" },
  "Off Duty": { en: "Off Duty", ta: "பணி இல்லை" },
  "Online": { en: "Online", ta: "ஆன்லைன்" },
  "Offline": { en: "Offline", ta: "ஆஃப்லைன்" },
  "Emergency Active": { en: "Emergency Active", ta: "அவசரநிலை செயல்பாட்டில்" },
  "Emergency Inactive": { en: "Emergency Inactive", ta: "அவசரநிலை இல்லை" },
  "Safe": { en: "Safe", ta: "பாதுகாப்பாக" },
  "Send Alert": { en: "Send Alert", ta: "எச்சரிக்கை அனுப்பு" },
  "Enable Sound": { en: "Enable Sound", ta: "ஒலி இயக்கு" },
  "Disable Sound": { en: "Disable Sound", ta: "ஒலி நிறுத்து" },
  "Refresh Location": { en: "Refresh Location", ta: "இடத்தை புதுப்பி" },
  "Profile": { en: "Profile", ta: "சுயவிவரம்" },
  "Settings": { en: "Settings", ta: "அமைப்புகள்" },
  "Full Name": { en: "Full Name", ta: "முழு பெயர்" },
  "Phone Number": { en: "Phone Number", ta: "தொலைபேசி எண்" },
  "Email Address": { en: "Email Address", ta: "மின்னஞ்சல் முகவரி" },
  "Password": { en: "Password", ta: "கடவுச்சொல்" },
  "Confirm Password": { en: "Confirm Password", ta: "கடவுச்சொல் உறுதிப்படுத்து" },
  "Ambulance Service Type": { en: "Ambulance Service Type", ta: "ஆம்புலன்ஸ் சேவை வகை" },
  "Hospital/Organization": { en: "Hospital/Organization", ta: "மருத்துவமனை/நிறுவனம்" },
  "Base Location": { en: "Base Location", ta: "அடிப்படை இடம்" },
  "Emergency Contact": { en: "Emergency Contact", ta: "அவசர தொடர்பு" },
  "Driving License": { en: "Driving License", ta: "ஓட்டுநர் உரிமம்" },
  "Government ID": { en: "Government ID", ta: "அரசு அடையாள அட்டை" },
  "I agree to terms": { en: "I agree to terms", ta: "விதிமுறைகளை ஒப்புக்கொள்கிறேன்" },
  "OTP Verification": { en: "OTP Verification", ta: "OTP சரிபார்ப்பு" },
  "Enter OTP": { en: "Enter OTP", ta: "OTP உள்ளிடுக" },
  "Resend OTP": { en: "Resend OTP", ta: "OTP மீண்டும் அனுப்பு" },
  "Verify": { en: "Verify", ta: "சரிபார்" },
  "Emergency approaching! Please give way.": { en: "Emergency approaching! Please give way.", ta: "அவசரவாகனம் வருகிறது! வழி விடுங்கள்." },
  "Ambulance is approaching your area": { en: "Ambulance is approaching your area", ta: "ஆம்புலன்ஸ் உங்கள் பகுதியில் வருகிறது" },
  "Vehicle Number": { en: "Vehicle Number", ta: "வாகன எண்" },
  "User Type": { en: "User Type", ta: "பயனர் வகை" },
  "Civilian": { en: "Civilian", ta: "பொதுமக்கள்" },
  "Car Driver": { en: "Car Driver", ta: "கார் ஓட்டுனர்" },
  "Bike Rider": { en: "Bike Rider", ta: "இரு சக்கர வாகன ஓட்டுனர்" },
  "Auto Driver": { en: "Auto Driver", ta: "ஆட்டோ ஓட்டுனர்" },
  "Bus Driver": { en: "Bus Driver", ta: "பஸ் ஓட்டுனர்" },
  "Truck Driver": { en: "Truck Driver", ta: "லாரி ஓட்டுனர்" },
  "Karur Ambulance Emergency Portal": { en: "Karur Ambulance Emergency Portal", ta: "கரூர் ஆம்புலன்ஸ் அவசர போர்டல்" },
  "Ambulance Portal": { en: "Ambulance Portal", ta: "ஆம்புலன்ஸ் போர்டல்" },
  "Public Portal": { en: "Public Portal", ta: "பொதுமக்கள் போர்டல்" },
  "Welcome Back": { en: "Welcome Back", ta: "மீண்டும் வருக" },
  "Create Account": { en: "Create Account", ta: "கணக்கை உருவாக்கு" },
  "Loading...": { en: "Loading...", ta: "ஏற்றுகிறது..." },
  "No active emergencies": { en: "No active emergencies", ta: "செயலில் அவசரநிலைகள் இல்லை" },
  "Your status is safe. No ambulances nearby.": { en: "Your status is safe. No ambulances nearby.", ta: "உங்கள் நிலை பாதுகாப்பானது. அருகில் ஆம்புலன்ஸ் இல்லை." },
  "Submit": { en: "Submit", ta: "சமர்ப்பி" },
  "Next": { en: "Next", ta: "அடுத்தது" },
  "Back": { en: "Back", ta: "பின்னால்" },
  "Don't have an account?": { en: "Don't have an account?", ta: "கணக்கு இல்லையா?" },
  "Already have an account?": { en: "Already have an account?", ta: "ஏற்கனவே கணக்கு உள்ளதா?" }
};

export function getTranslation(key: string, lang: Language): string {
  if (translations[key]) {
    return translations[key][lang] || key;
  }
  // Fallback to English key if not found to avoid blank UI
  return key;
}
