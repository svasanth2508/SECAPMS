import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

import { LanguageProvider } from "./contexts/language-context";
import { AuthProvider, useAuth } from "./contexts/auth-context";

import LandingPage from "./pages/landing";
import DriverLogin from "./pages/auth/driver-login";
import DriverRegister from "./pages/auth/driver-register";
import PublicLogin from "./pages/auth/public-login";
import PublicRegister from "./pages/auth/public-register";
import DriverDashboard from "./pages/dashboard/driver-dashboard";
import PublicDashboard from "./pages/dashboard/public-dashboard";
import NotFound from "./pages/not-found";

const queryClient = new QueryClient();

// Protected Route Wrapper
function ProtectedRoute({ component: Component, role }: { component: React.ComponentType, role: 'driver' | 'public' }) {
  const { isAuthenticated, isDriver, isPublic, isLoading } = useAuth();

  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  if (!isAuthenticated) {
    // Redirect to respective login
    window.location.href = role === 'driver' ? '/ambulance/login' : '/public/login';
    return null;
  }

  if (role === 'driver' && !isDriver) {
    window.location.href = '/public/dashboard';
    return null;
  }

  if (role === 'public' && !isPublic) {
    window.location.href = '/ambulance/dashboard';
    return null;
  }

  return <Component />;
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={LandingPage} />
      
      {/* Auth Routes */}
      <Route path="/ambulance/login" component={DriverLogin} />
      <Route path="/ambulance/register" component={DriverRegister} />
      <Route path="/public/login" component={PublicLogin} />
      <Route path="/public/register" component={PublicRegister} />

      {/* Protected Dashboards */}
      <Route path="/ambulance/dashboard">
        {() => <ProtectedRoute component={DriverDashboard} role="driver" />}
      </Route>
      <Route path="/public/dashboard">
        {() => <ProtectedRoute component={PublicDashboard} role="public" />}
      </Route>

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <LanguageProvider>
        <AuthProvider>
          <TooltipProvider>
            <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
              <Router />
            </WouterRouter>
            <Toaster />
          </TooltipProvider>
        </AuthProvider>
      </LanguageProvider>
    </QueryClientProvider>
  );
}

export default App;
