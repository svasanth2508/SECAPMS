import React from 'react';
import { useLanguage } from '@/contexts/language-context';
import { LanguageToggle } from '@/components/layout/language-toggle';
import { Link } from 'wouter';
import { motion } from 'framer-motion';
import { Activity, ShieldAlert, Users } from 'lucide-react';

export default function LandingPage() {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-background relative overflow-hidden flex flex-col">
      {/* Background with overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src={`${import.meta.env.BASE_URL}images/hero-bg.png`}
          alt="Emergency Background"
          className="w-full h-full object-cover opacity-10"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/95 to-background" />
      </div>

      <header className="relative z-10 p-6 flex justify-between items-center max-w-7xl mx-auto w-full">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-primary rounded-2xl flex items-center justify-center shadow-lg shadow-primary/20">
            <Activity className="w-7 h-7 text-primary-foreground" />
          </div>
          <div>
            <h1 className="font-display font-extrabold text-2xl tracking-tight text-foreground">Karur</h1>
            <p className="text-xs font-bold text-primary tracking-widest uppercase">Emergency</p>
          </div>
        </div>
        <LanguageToggle />
      </header>

      <main className="relative z-10 flex-1 flex flex-col items-center justify-center px-4 max-w-5xl mx-auto w-full pb-20">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-6xl font-black mb-6 leading-tight">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-foreground to-foreground/70">
              {t("Karur Ambulance Emergency Portal")}
            </span>
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto font-medium">
            Bridging the gap between emergency services and the public to ensure faster, safer transit for ambulances in Karur.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full max-w-4xl">
          {/* Driver Portal Card */}
          <Link href="/ambulance/login" className="block group">
            <motion.div 
              whileHover={{ y: -5 }}
              className="bg-card h-full p-8 rounded-3xl border-2 border-border/50 shadow-xl shadow-black/5 hover:border-primary/50 hover:shadow-primary/10 transition-all duration-300 relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full blur-3xl -mr-10 -mt-10 transition-all group-hover:bg-primary/10" />
              <div className="w-16 h-16 bg-primary/10 text-primary rounded-2xl flex items-center justify-center mb-6">
                <ShieldAlert className="w-8 h-8" />
              </div>
              <h3 className="text-2xl font-bold mb-3 group-hover:text-primary transition-colors">
                {t("Ambulance Portal")}
              </h3>
              <p className="text-muted-foreground font-medium mb-6">
                For authorized ambulance drivers. Manage your duty status, start emergency broadcasts, and alert nearby vehicles.
              </p>
              <div className="flex items-center text-primary font-bold text-sm">
                Enter Portal <span className="ml-2 group-hover:translate-x-1 transition-transform">→</span>
              </div>
            </motion.div>
          </Link>

          {/* Public Portal Card */}
          <Link href="/public/login" className="block group">
            <motion.div 
              whileHover={{ y: -5 }}
              className="bg-card h-full p-8 rounded-3xl border-2 border-border/50 shadow-xl shadow-black/5 hover:border-blue-500/50 hover:shadow-blue-500/10 transition-all duration-300 relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full blur-3xl -mr-10 -mt-10 transition-all group-hover:bg-blue-500/10" />
              <div className="w-16 h-16 bg-blue-500/10 text-blue-600 rounded-2xl flex items-center justify-center mb-6">
                <Users className="w-8 h-8" />
              </div>
              <h3 className="text-2xl font-bold mb-3 group-hover:text-blue-600 transition-colors">
                {t("Public Portal")}
              </h3>
              <p className="text-muted-foreground font-medium mb-6">
                For citizens and motorists. Receive real-time alerts when an emergency vehicle is approaching your location.
              </p>
              <div className="flex items-center text-blue-600 font-bold text-sm">
                Enter Portal <span className="ml-2 group-hover:translate-x-1 transition-transform">→</span>
              </div>
            </motion.div>
          </Link>
        </div>
      </main>
    </div>
  );
}
