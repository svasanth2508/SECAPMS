import React from 'react';
import { useLanguage } from '@/contexts/language-context';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { AlertCircle } from 'lucide-react';

export default function NotFound() {
  const { t } = useLanguage();
  
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4 text-center">
      <AlertCircle className="w-20 h-20 text-muted-foreground mb-6" />
      <h1 className="text-4xl font-black mb-2">404</h1>
      <p className="text-xl text-muted-foreground mb-8">Page not found</p>
      <Link href="/">
        <Button size="lg" className="rounded-xl font-bold">
          Return Home
        </Button>
      </Link>
    </div>
  );
}
