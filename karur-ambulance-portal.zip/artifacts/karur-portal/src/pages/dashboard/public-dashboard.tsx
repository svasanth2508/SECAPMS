import React, { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { EmergencyBanner } from '@/components/shared/emergency-banner';
import { useLanguage } from '@/contexts/language-context';
import { Card, CardContent } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { MapPin, ShieldCheck, AlertTriangle, Volume2, VolumeX, Bell } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function PublicDashboard() {
  const { t } = useLanguage();
  const [soundEnabled, setSoundEnabled] = useState(true);
  
  // MOCK STATE for demonstration - usually this comes from React Query polling
  const [activeAlerts, setActiveAlerts] = useState<any[]>([]);

  // Simulate an emergency appearing after 5 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      setActiveAlerts([{
        id: 1,
        ambulanceNumber: "TN 47 AZ 9988",
        distanceKm: 1.2,
        message: "Approaching Karur Roundana"
      }]);
    }, 5000);
    return () => clearTimeout(timer);
  }, []);

  const hasEmergency = activeAlerts.length > 0;

  return (
    <DashboardLayout isEmergencyActive={hasEmergency}>
      <EmergencyBanner 
        isActive={hasEmergency} 
        message={activeAlerts[0]?.message} 
      />

      <div className={`max-w-4xl mx-auto space-y-6 ${hasEmergency ? 'mt-24' : ''} transition-all duration-500`}>
        
        {/* Main Status Card */}
        <AnimatePresence mode="wait">
          <motion.div
            key={hasEmergency ? 'danger' : 'safe'}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <Card className={`border-2 overflow-hidden shadow-xl ${
              hasEmergency ? 'border-destructive shadow-destructive/20' : 'border-green-500/30 shadow-green-500/5'
            }`}>
              <div className={`h-2 w-full ${hasEmergency ? 'bg-destructive' : 'bg-green-500'}`} />
              <CardContent className="p-8 md:p-12 text-center">
                <div className={`mx-auto w-24 h-24 rounded-full flex items-center justify-center mb-6 ${
                  hasEmergency ? 'bg-destructive/10 text-destructive' : 'bg-green-500/10 text-green-500'
                }`}>
                  {hasEmergency ? <AlertTriangle className="w-12 h-12" /> : <ShieldCheck className="w-12 h-12" />}
                </div>
                
                <h2 className="text-3xl md:text-4xl font-black mb-4">
                  {hasEmergency ? t("Ambulance Nearby") : t("Safe")}
                </h2>
                
                <p className={`text-lg font-medium ${hasEmergency ? 'text-destructive' : 'text-muted-foreground'}`}>
                  {hasEmergency 
                    ? t("Emergency approaching! Please give way.") 
                    : t("Your status is safe. No ambulances nearby.")}
                </p>

                {hasEmergency && (
                  <div className="mt-8 bg-destructive/5 rounded-2xl p-6 border border-destructive/20 inline-block text-left">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow text-destructive font-bold text-xl">
                        {activeAlerts[0].distanceKm}
                      </div>
                      <div>
                        <p className="text-sm font-bold text-destructive uppercase">{t("Distance")}</p>
                        <p className="text-foreground font-black text-xl">Kilometers</p>
                      </div>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">{t("Ambulance Number")}</p>
                      <p className="font-bold bg-white px-3 py-1 rounded border inline-block">{activeAlerts[0].ambulanceNumber}</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </AnimatePresence>

        {/* Settings & Info Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="border border-border/50 shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-6 border-b pb-4">
                <h3 className="font-bold text-lg flex items-center">
                  <Volume2 className="w-5 h-5 mr-2 text-blue-600" /> {t("Settings")}
                </h3>
              </div>
              <div className="flex items-center justify-between bg-muted/50 p-4 rounded-xl">
                <div className="flex items-center gap-3">
                  {soundEnabled ? <Volume2 className="text-slate-600" /> : <VolumeX className="text-slate-400" />}
                  <div>
                    <p className="font-bold">{t("Enable Sound")}</p>
                    <p className="text-xs text-muted-foreground">Play siren for active alerts</p>
                  </div>
                </div>
                <Switch checked={soundEnabled} onCheckedChange={setSoundEnabled} className="data-[state=checked]:bg-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border border-border/50 shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-6 border-b pb-4">
                <h3 className="font-bold text-lg flex items-center">
                  <Bell className="w-5 h-5 mr-2 text-blue-600" /> {t("Notification History")}
                </h3>
              </div>
              <div className="space-y-4">
                <div className="bg-muted/50 p-3 rounded-lg border border-border/50">
                  <p className="text-xs text-muted-foreground mb-1">Yesterday, 14:30</p>
                  <p className="font-medium text-sm">Ambulance passed safely. Thank you for giving way.</p>
                </div>
                <div className="bg-muted/50 p-3 rounded-lg border border-border/50 opacity-70">
                  <p className="text-xs text-muted-foreground mb-1">Oct 12, 09:15</p>
                  <p className="font-medium text-sm">Test notification received.</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

      </div>
    </DashboardLayout>
  );
}
