import React, { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { useLanguage } from '@/contexts/language-context';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { RadioReceiver, Navigation, ShieldCheck, Clock, Users, Activity } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '@/hooks/use-toast';

// Mock driver state
export default function DriverDashboard() {
  const { t } = useLanguage();
  const { toast } = useToast();
  const [isOnDuty, setIsOnDuty] = useState(true);
  const [isOnline, setIsOnline] = useState(true);
  const [isEmergencyActive, setIsEmergencyActive] = useState(false);
  const [nearbyUsers, setNearbyUsers] = useState(12);

  // Simulate updating nearby users while emergency is active
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isEmergencyActive) {
      interval = setInterval(() => {
        setNearbyUsers(prev => prev + Math.floor(Math.random() * 5));
      }, 5000);
    } else {
      setNearbyUsers(12);
    }
    return () => clearInterval(interval);
  }, [isEmergencyActive]);

  const toggleEmergency = () => {
    if (!isOnDuty || !isOnline) {
      toast({
        title: "Action Denied",
        description: "You must be On Duty and Online to start an emergency.",
        variant: "destructive"
      });
      return;
    }
    
    setIsEmergencyActive(!isEmergencyActive);
    if (!isEmergencyActive) {
      toast({
        title: t("Emergency Active"),
        description: "Broadcasting alert to nearby vehicles.",
        variant: "destructive"
      });
    } else {
      toast({
        title: t("Safe"),
        description: "Emergency broadcast stopped.",
      });
    }
  };

  return (
    <DashboardLayout isEmergencyActive={isEmergencyActive}>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
        
        {/* Left Column: Actions & Emergency Control */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="border-2 border-border/50 shadow-lg shadow-black/5 overflow-hidden">
            <div className={`h-3 w-full ${isEmergencyActive ? 'bg-destructive pulse-emergency' : 'bg-primary'}`} />
            <CardContent className="p-8">
              <div className="flex flex-col items-center justify-center text-center space-y-8">
                
                <AnimatePresence mode="wait">
                  <motion.div
                    key={isEmergencyActive ? 'active' : 'inactive'}
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.8, opacity: 0 }}
                    className="flex flex-col items-center"
                  >
                    <div className={`w-32 h-32 rounded-full flex items-center justify-center mb-6 shadow-2xl ${isEmergencyActive ? 'bg-destructive shadow-destructive/40 pulse-emergency' : 'bg-slate-100 shadow-slate-200'}`}>
                      {isEmergencyActive ? (
                        <RadioReceiver className="w-16 h-16 text-white animate-pulse" />
                      ) : (
                        <ShieldCheck className="w-16 h-16 text-slate-400" />
                      )}
                    </div>
                    <h2 className={`text-3xl font-black uppercase tracking-widest ${isEmergencyActive ? 'text-destructive' : 'text-slate-400'}`}>
                      {isEmergencyActive ? t("Emergency Active") : t("Emergency Inactive")}
                    </h2>
                  </motion.div>
                </AnimatePresence>

                <Button 
                  onClick={toggleEmergency}
                  size="lg"
                  className={`w-full max-w-md h-24 text-2xl font-black uppercase tracking-widest rounded-2xl shadow-xl transition-all duration-300 ${
                    isEmergencyActive 
                    ? 'bg-slate-900 hover:bg-slate-800 text-white shadow-slate-900/20' 
                    : 'bg-gradient-to-r from-destructive to-red-500 hover:from-red-700 hover:to-red-600 text-white shadow-destructive/30 hover:scale-105'
                  }`}
                >
                  {isEmergencyActive ? t("Stop Emergency") : t("Start Emergency")}
                </Button>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-2 gap-4">
            <Card className="border border-border/50 shadow-sm">
              <CardContent className="p-6 flex flex-col items-center text-center justify-center">
                <Clock className="w-8 h-8 text-primary mb-3" />
                <h3 className="font-bold text-lg mb-4">{t("Status")}</h3>
                <Button 
                  variant={isOnDuty ? "default" : "outline"} 
                  className={`w-full rounded-xl ${isOnDuty ? 'bg-primary' : ''}`}
                  onClick={() => setIsOnDuty(!isOnDuty)}
                  disabled={isEmergencyActive}
                >
                  {isOnDuty ? t("End Duty") : t("Start Duty")}
                </Button>
              </CardContent>
            </Card>

            <Card className="border border-border/50 shadow-sm">
              <CardContent className="p-6 flex flex-col items-center text-center justify-center">
                <Navigation className={`w-8 h-8 mb-3 ${isOnline ? 'text-green-500' : 'text-slate-400'}`} />
                <h3 className="font-bold text-lg mb-4">{t("Location")}</h3>
                <div className="flex items-center gap-3">
                  <span className={`font-semibold ${!isOnline ? 'text-muted-foreground' : ''}`}>{t("Offline")}</span>
                  <Switch 
                    checked={isOnline} 
                    onCheckedChange={setIsOnline} 
                    disabled={isEmergencyActive}
                    className="data-[state=checked]:bg-green-500"
                  />
                  <span className={`font-semibold ${isOnline ? 'text-green-500' : 'text-muted-foreground'}`}>{t("Online")}</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Right Column: Info & Stats */}
        <div className="space-y-6">
          <Card className="border border-border/50 shadow-sm bg-gradient-to-b from-card to-muted/20">
            <CardContent className="p-6">
              <h3 className="font-bold text-lg mb-6 flex items-center border-b pb-4">
                <UserIcon /> <span className="ml-2">{t("Profile")}</span>
              </h3>
              <div className="space-y-4">
                <div>
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{t("Driver Name")}</p>
                  <p className="font-bold text-foreground text-lg">Karur Driver Test</p>
                </div>
                <div>
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{t("Ambulance Number")}</p>
                  <p className="font-bold text-foreground text-lg bg-muted px-3 py-1 rounded-md inline-block mt-1 border">TN 47 AZ 9988</p>
                </div>
                <div>
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{t("Base Location")}</p>
                  <p className="font-medium text-foreground">Karur Govt Hospital</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border border-border/50 shadow-sm overflow-hidden relative">
            {isEmergencyActive && (
              <div className="absolute inset-0 bg-primary/5 animate-pulse z-0" />
            )}
            <CardContent className="p-6 relative z-10">
              <h3 className="font-bold text-lg mb-2 flex items-center">
                <Users className="w-5 h-5 mr-2 text-primary" /> {t("Nearby Users")}
              </h3>
              <p className="text-sm text-muted-foreground mb-4">Users notified in 5km radius</p>
              
              <div className="flex items-baseline gap-2">
                <span className="text-5xl font-black text-foreground">{nearbyUsers}</span>
                <span className="text-green-500 font-bold flex items-center">
                  <Activity className="w-4 h-4 mr-1" /> Live
                </span>
              </div>
            </CardContent>
          </Card>
        </div>

      </div>
    </DashboardLayout>
  );
}

const UserIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>;
