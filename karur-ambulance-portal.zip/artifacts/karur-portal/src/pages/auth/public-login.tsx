import React from 'react';
import { useLanguage } from '@/contexts/language-context';
import { useAuth } from '@/contexts/auth-context';
import { LanguageToggle } from '@/components/layout/language-toggle';
import { Link, useLocation } from 'wouter';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Users, ArrowLeft } from 'lucide-react';
import { motion } from 'framer-motion';

const loginSchema = z.object({
  phone: z.string().min(10, 'Valid phone number required'),
  password: z.string().min(6, 'Password required'),
});

type LoginForm = z.infer<typeof loginSchema>;

export default function PublicLogin() {
  const { t } = useLanguage();
  const { login: authLogin } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<LoginForm>({
    resolver: zodResolver(loginSchema)
  });

  const onSubmit = async (data: LoginForm) => {
    try {
      // MOCK LOGIN FOR DEVELOPMENT
      setTimeout(() => {
        authLogin("mock-jwt-token-public", {
          id: 2,
          name: "Citizen Test",
          email: "citizen@karur.gov",
          phone: data.phone,
          role: "public",
          isVerified: true
        });
        toast({ title: "Success", description: "Logged in successfully" });
        setLocation('/public/dashboard');
      }, 500);
    } catch (err: any) {
      toast({ title: "Error", description: "Failed to login", variant: "destructive" });
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <header className="p-4 flex justify-between items-center absolute w-full top-0">
        <Link href="/" className="text-slate-500 hover:text-slate-900 flex items-center font-medium">
          <ArrowLeft className="w-4 h-4 mr-2" /> {t("Back")}
        </Link>
        <LanguageToggle />
      </header>

      <div className="flex-1 flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white w-full max-w-md p-8 rounded-3xl shadow-xl shadow-slate-200/50 border border-slate-200"
        >
          <div className="w-16 h-16 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center mb-6 mx-auto">
            <Users className="w-8 h-8" />
          </div>
          <h2 className="text-2xl font-black text-center mb-2 text-slate-900">{t("Public Portal")}</h2>
          <p className="text-center text-slate-500 font-medium mb-8">{t("Welcome Back")} - {t("Login")}</p>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="phone" className="text-slate-700">{t("Phone Number")}</Label>
              <Input 
                id="phone" 
                type="tel" 
                placeholder="9876543210" 
                className="bg-slate-50 border-slate-200 focus-visible:ring-blue-500 rounded-xl"
                {...register('phone')} 
              />
              {errors.phone && <p className="text-destructive text-sm font-medium">{errors.phone.message}</p>}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password" className="text-slate-700">{t("Password")}</Label>
              <Input 
                id="password" 
                type="password" 
                className="bg-slate-50 border-slate-200 focus-visible:ring-blue-500 rounded-xl"
                {...register('password')} 
              />
              {errors.password && <p className="text-destructive text-sm font-medium">{errors.password.message}</p>}
            </div>

            <Button 
              type="submit" 
              className="w-full rounded-xl py-6 font-bold text-lg bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-600/25 hover:-translate-y-0.5 transition-all"
              disabled={isSubmitting}
            >
              {isSubmitting ? t("Loading...") : t("Login")}
            </Button>
          </form>

          <div className="mt-8 text-center">
            <p className="text-slate-500 font-medium">
              {t("Don't have an account?")} <Link href="/public/register" className="text-blue-600 font-bold hover:underline">{t("Register")}</Link>
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
