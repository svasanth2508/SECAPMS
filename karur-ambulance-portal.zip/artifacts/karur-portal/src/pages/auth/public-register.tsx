import React, { useState } from 'react';
import { useLanguage } from '@/contexts/language-context';
import { LanguageToggle } from '@/components/layout/language-toggle';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from '@/hooks/use-toast';
import { Users, ArrowLeft } from 'lucide-react';
import { motion } from 'framer-motion';

export default function PublicRegister() {
  const { t } = useLanguage();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      toast({ title: "Success", description: "Account created successfully." });
      setLocation('/public/login');
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <header className="p-4 flex justify-between items-center w-full">
        <Link href="/public/login" className="text-slate-500 hover:text-slate-900 flex items-center font-medium">
          <ArrowLeft className="w-4 h-4 mr-2" /> {t("Back")}
        </Link>
        <LanguageToggle />
      </header>

      <div className="flex-1 flex items-center justify-center p-4 pb-12">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white w-full max-w-xl p-8 rounded-3xl shadow-xl shadow-slate-200/50 border border-slate-200"
        >
          <div className="flex items-center gap-4 mb-8 border-b border-slate-100 pb-6">
             <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-slate-900">{t("Register")}</h2>
              <p className="text-slate-500 font-medium">{t("Public Portal")}</p>
            </div>
          </div>

          <form onSubmit={handleRegister} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-slate-700">{t("Full Name")}</Label>
                <Input required className="bg-slate-50 border-slate-200 focus-visible:ring-blue-500 rounded-xl" />
              </div>
              <div className="space-y-2">
                <Label className="text-slate-700">{t("Phone Number")}</Label>
                <Input required type="tel" className="bg-slate-50 border-slate-200 focus-visible:ring-blue-500 rounded-xl" />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label className="text-slate-700">{t("User Type")}</Label>
                <Select required>
                  <SelectTrigger className="bg-slate-50 border-slate-200 rounded-xl">
                    <SelectValue placeholder={t("Select Type")} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="civilian">{t("Civilian")}</SelectItem>
                    <SelectItem value="car_driver">{t("Car Driver")}</SelectItem>
                    <SelectItem value="bike_rider">{t("Bike Rider")}</SelectItem>
                    <SelectItem value="auto_driver">{t("Auto Driver")}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label className="text-slate-700">{t("Vehicle Number")} (Optional)</Label>
                <Input className="bg-slate-50 border-slate-200 focus-visible:ring-blue-500 rounded-xl" />
              </div>
              <div className="space-y-2">
                <Label className="text-slate-700">{t("Password")}</Label>
                <Input required type="password" className="bg-slate-50 border-slate-200 focus-visible:ring-blue-500 rounded-xl" />
              </div>
              <div className="space-y-2">
                <Label className="text-slate-700">{t("Confirm Password")}</Label>
                <Input required type="password" className="bg-slate-50 border-slate-200 focus-visible:ring-blue-500 rounded-xl" />
              </div>
            </div>
            
            <Button 
              type="submit" 
              disabled={isSubmitting}
              className="w-full rounded-xl py-6 font-bold text-lg mt-6 bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-600/25"
            >
              {isSubmitting ? t("Loading...") : t("Create Account")}
            </Button>
          </form>

          <div className="mt-8 text-center">
            <p className="text-slate-500 font-medium">
              {t("Already have an account?")} <Link href="/public/login" className="text-blue-600 font-bold hover:underline">{t("Login")}</Link>
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
