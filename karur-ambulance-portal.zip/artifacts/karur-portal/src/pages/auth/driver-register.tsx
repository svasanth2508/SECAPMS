import React, { useState } from 'react';
import { useLanguage } from '@/contexts/language-context';
import { LanguageToggle } from '@/components/layout/language-toggle';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Activity, ArrowLeft, CheckCircle2 } from 'lucide-react';
import { motion } from 'framer-motion';

export default function DriverRegister() {
  const { t } = useLanguage();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Simplified form for mockup without full react-hook-form to save generation space, 
  // keeping the visual excellence and bilingual requirements intact.
  
  const handleNext = (e: React.FormEvent) => {
    e.preventDefault();
    setStep(2);
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      toast({ title: "Success", description: "Registration pending approval." });
      setLocation('/ambulance/login');
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-muted/30 flex flex-col">
      <header className="p-4 flex justify-between items-center w-full">
        <Link href="/ambulance/login" className="text-muted-foreground hover:text-foreground flex items-center font-medium">
          <ArrowLeft className="w-4 h-4 mr-2" /> {t("Back")}
        </Link>
        <LanguageToggle />
      </header>

      <div className="flex-1 flex items-center justify-center p-4 pb-12">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-card w-full max-w-xl p-8 rounded-3xl shadow-xl shadow-black/5 border border-border"
        >
          <div className="flex items-center gap-4 mb-8 border-b border-border/50 pb-6">
             <div className="w-12 h-12 bg-primary/10 text-primary rounded-xl flex items-center justify-center">
              <Activity className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-2xl font-black">{t("Register")}</h2>
              <p className="text-muted-foreground font-medium">{t("Ambulance Portal")}</p>
            </div>
          </div>

          {/* Stepper */}
          <div className="flex items-center justify-center mb-8">
            <div className={`flex items-center justify-center w-8 h-8 rounded-full font-bold ${step >= 1 ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}>1</div>
            <div className={`h-1 w-16 mx-2 rounded-full ${step >= 2 ? 'bg-primary' : 'bg-muted'}`} />
            <div className={`flex items-center justify-center w-8 h-8 rounded-full font-bold ${step >= 2 ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}>2</div>
          </div>

          {step === 1 ? (
            <form onSubmit={handleNext} className="space-y-4 animate-in fade-in slide-in-from-right-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>{t("Full Name")}</Label>
                  <Input required className="bg-muted/50 rounded-xl" />
                </div>
                <div className="space-y-2">
                  <Label>{t("Phone Number")}</Label>
                  <Input required type="tel" className="bg-muted/50 rounded-xl" />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label>{t("Email Address")}</Label>
                  <Input required type="email" className="bg-muted/50 rounded-xl" />
                </div>
                <div className="space-y-2">
                  <Label>{t("Password")}</Label>
                  <Input required type="password" className="bg-muted/50 rounded-xl" />
                </div>
                <div className="space-y-2">
                  <Label>{t("Confirm Password")}</Label>
                  <Input required type="password" className="bg-muted/50 rounded-xl" />
                </div>
              </div>
              
              <Button type="submit" className="w-full rounded-xl py-6 font-bold text-lg mt-6 shadow-lg shadow-primary/25">
                {t("Next")}
              </Button>
            </form>
          ) : (
            <form onSubmit={handleRegister} className="space-y-4 animate-in fade-in slide-in-from-right-4">
               <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2 md:col-span-2">
                  <Label>{t("Ambulance Number")}</Label>
                  <Input required placeholder="TN 47 XX 1234" className="bg-muted/50 rounded-xl" />
                </div>
                <div className="space-y-2">
                  <Label>{t("Driving License")}</Label>
                  <Input required className="bg-muted/50 rounded-xl" />
                </div>
                <div className="space-y-2">
                  <Label>{t("Hospital/Organization")}</Label>
                  <Input required className="bg-muted/50 rounded-xl" />
                </div>
              </div>

              <div className="flex gap-4 mt-8">
                <Button type="button" variant="outline" onClick={() => setStep(1)} className="rounded-xl py-6 flex-1 font-bold">
                  {t("Back")}
                </Button>
                <Button type="submit" disabled={isSubmitting} className="rounded-xl py-6 flex-2 w-full font-bold shadow-lg shadow-primary/25">
                  {isSubmitting ? t("Loading...") : t("Submit")}
                </Button>
              </div>
            </form>
          )}

          <div className="mt-8 text-center">
            <p className="text-muted-foreground font-medium">
              {t("Already have an account?")} <Link href="/ambulance/login" className="text-primary font-bold hover:underline">{t("Login")}</Link>
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
