import React from 'react';
import { useLanguage } from '@/contexts/language-context';
import { useAuth } from '@/contexts/auth-context';
import { LanguageToggle } from '@/components/layout/language-toggle';
import { Link, useLocation } from 'wouter';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useLogin, LoginRequestRole } from '@workspace/api-client-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Activity, ArrowLeft } from 'lucide-react';
import { motion } from 'framer-motion';

const loginSchema = z.object({
  phone: z.string().min(10, 'Valid phone number required'),
  password: z.string().min(6, 'Password required'),
});

type LoginForm = z.infer<typeof loginSchema>;

export default function DriverLogin() {
  const { t } = useLanguage();
  const { login: authLogin } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const { register, handleSubmit, formState: { errors } } = useForm<LoginForm>({
    resolver: zodResolver(loginSchema)
  });

  const loginMutation = useLogin();

  const onSubmit = async (data: LoginForm) => {
    try {
      // Simulate API call for now since we don't have a real DB backing the auth yet
      // In a real app, we'd uncomment this:
      /*
      const response = await loginMutation.mutateAsync({
        data: {
          phone: data.phone,
          password: data.password,
          role: LoginRequestRole.driver
        }
      });
      authLogin(response.token, response.user);
      */
      
      // MOCK LOGIN FOR DEVELOPMENT
      authLogin("mock-jwt-token-123", {
        id: 1,
        name: "Karur Driver Test",
        email: "driver@karur.gov",
        phone: data.phone,
        role: "driver",
        isVerified: true
      });
      
      toast({ title: "Success", description: "Logged in successfully" });
      setLocation('/ambulance/dashboard');
    } catch (err: any) {
      toast({ 
        title: "Error", 
        description: err.message || "Failed to login",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen bg-muted/30 flex flex-col">
      <header className="p-4 flex justify-between items-center absolute w-full top-0">
        <Link href="/" className="text-muted-foreground hover:text-foreground flex items-center font-medium">
          <ArrowLeft className="w-4 h-4 mr-2" /> {t("Back")}
        </Link>
        <LanguageToggle />
      </header>

      <div className="flex-1 flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-card w-full max-w-md p-8 rounded-3xl shadow-xl shadow-black/5 border border-border"
        >
          <div className="w-16 h-16 bg-primary/10 text-primary rounded-2xl flex items-center justify-center mb-6 mx-auto">
            <Activity className="w-8 h-8" />
          </div>
          <h2 className="text-2xl font-black text-center mb-2">{t("Ambulance Portal")}</h2>
          <p className="text-center text-muted-foreground font-medium mb-8">{t("Welcome Back")} - {t("Login")}</p>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="phone">{t("Phone Number")}</Label>
              <Input 
                id="phone" 
                type="tel" 
                placeholder="9876543210" 
                className="bg-muted/50 rounded-xl"
                {...register('phone')} 
              />
              {errors.phone && <p className="text-destructive text-sm font-medium">{errors.phone.message}</p>}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password">{t("Password")}</Label>
              <Input 
                id="password" 
                type="password" 
                className="bg-muted/50 rounded-xl"
                {...register('password')} 
              />
              {errors.password && <p className="text-destructive text-sm font-medium">{errors.password.message}</p>}
            </div>

            <Button 
              type="submit" 
              className="w-full rounded-xl py-6 font-bold text-lg shadow-lg shadow-primary/25 hover:-translate-y-0.5 transition-all"
              disabled={loginMutation.isPending}
            >
              {loginMutation.isPending ? t("Loading...") : t("Login")}
            </Button>
          </form>

          <div className="mt-8 text-center">
            <p className="text-muted-foreground font-medium">
              {t("Don't have an account?")} <Link href="/ambulance/register" className="text-primary font-bold hover:underline">{t("Register")}</Link>
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
