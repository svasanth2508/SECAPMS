import React from 'react';
import { useAuth } from '@/contexts/auth-context';
import { useLanguage } from '@/contexts/language-context';
import { LanguageToggle } from './language-toggle';
import { Button } from '@/components/ui/button';
import { LogOut, Activity, User, Home, Bell } from 'lucide-react';
import { useLocation, Link } from 'wouter';

export function DashboardLayout({ children, isEmergencyActive = false }: { children: React.ReactNode, isEmergencyActive?: boolean }) {
  const { user, logout, isDriver } = useAuth();
  const { t } = useLanguage();
  const [, setLocation] = useLocation();

  const handleLogout = () => {
    logout();
    setLocation('/');
  };

  const portalType = isDriver ? t('Ambulance Portal') : t('Public Portal');

  return (
    <div className={`min-h-screen bg-background flex flex-col ${isEmergencyActive ? 'border-t-8 border-destructive' : ''}`}>
      <header className="sticky top-0 z-40 w-full backdrop-blur-xl bg-background/80 border-b border-border/40 shadow-sm">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-white shadow-lg ${isDriver ? 'bg-primary' : 'bg-blue-600'}`}>
              <Activity className="w-6 h-6" />
            </div>
            <div>
              <h1 className="font-display font-bold text-lg leading-tight text-foreground">
                {t('Karur Ambulance Emergency Portal')}
              </h1>
              <p className="text-xs font-semibold text-muted-foreground">{portalType}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <LanguageToggle />
            <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full bg-secondary/50 border border-secondary">
              <User className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm font-medium">{user?.name}</span>
            </div>
            <Button variant="ghost" size="icon" onClick={handleLogout} className="text-muted-foreground hover:text-destructive hover:bg-destructive/10">
              <LogOut className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </header>
      
      <main className="flex-1 container mx-auto px-4 py-8">
        {children}
      </main>
    </div>
  );
}
