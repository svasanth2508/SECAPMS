import React from 'react';
import { useLanguage } from '@/contexts/language-context';
import { Button } from '@/components/ui/button';
import { Languages } from 'lucide-react';
import { motion } from 'framer-motion';

export function LanguageToggle() {
  const { language, toggleLanguage } = useLanguage();

  return (
    <Button
      variant="outline"
      size="sm"
      onClick={toggleLanguage}
      className="rounded-full px-4 font-semibold shadow-sm hover:shadow-md transition-all border-primary/20 hover:border-primary/50 bg-background/80 backdrop-blur-sm"
    >
      <Languages className="w-4 h-4 mr-2 text-primary" />
      <span className={language === 'en' ? 'text-primary font-bold' : 'text-muted-foreground'}>EN</span>
      <span className="mx-2 text-border">|</span>
      <span className={language === 'ta' ? 'text-primary font-bold' : 'text-muted-foreground'}>தமிழ்</span>
    </Button>
  );
}
