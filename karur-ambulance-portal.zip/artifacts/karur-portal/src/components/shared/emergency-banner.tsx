import React from 'react';
import { motion } from 'framer-motion';
import { AlertTriangle } from 'lucide-react';
import { useLanguage } from '@/contexts/language-context';

interface EmergencyBannerProps {
  message?: string;
  isActive: boolean;
}

export function EmergencyBanner({ message, isActive }: EmergencyBannerProps) {
  const { t } = useLanguage();

  if (!isActive) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: -50 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -50 }}
      className="w-full bg-destructive text-destructive-foreground p-4 pulse-emergency z-50 fixed top-0 left-0 shadow-2xl flex items-center justify-center gap-4"
    >
      <AlertTriangle className="w-8 h-8 animate-bounce" />
      <div className="text-center">
        <h2 className="text-xl md:text-2xl font-black uppercase tracking-wider">
          {t("Emergency approaching! Please give way.")}
        </h2>
        {message && <p className="text-sm md:text-base font-semibold mt-1 opacity-90">{message}</p>}
      </div>
      <AlertTriangle className="w-8 h-8 animate-bounce" />
    </motion.div>
  );
}
