import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, usersTable, driverProfilesTable, publicProfilesTable, otpVerificationsTable } from "@workspace/db";
import { signToken, hashPassword, verifyPassword, generateOtp, requireAuth } from "../lib/auth";

const router: IRouter = Router();

router.post("/auth/register-driver", async (req, res): Promise<void> => {
  const {
    name, phone, email, password,
    ambulanceNumber, licenseNumber, govtId,
    serviceType, hospitalName, baseLocation,
    emergencyContact, consentAccepted
  } = req.body;

  if (!name || !email || !password || !ambulanceNumber || !licenseNumber || !govtId ||
      !serviceType || !hospitalName || !baseLocation || !emergencyContact || !consentAccepted) {
    res.status(400).json({ error: "validation_error", message: "All required fields must be provided" });
    return;
  }

  const existing = await db.select().from(usersTable).where(eq(usersTable.email, email)).limit(1);
  if (existing.length > 0) {
    res.status(400).json({ error: "duplicate_user", message: "Email already registered" });
    return;
  }

  const passwordHash = hashPassword(password);
  const [user] = await db.insert(usersTable).values({
    name, phone, email, passwordHash, role: "driver", isVerified: true,
  }).returning();

  await db.insert(driverProfilesTable).values({
    userId: user.id, ambulanceNumber, licenseNumber, govtId,
    serviceType, hospitalName, baseLocation, emergencyContact,
  });

  const token = signToken({ id: user.id, role: "driver", email: user.email });
  res.status(201).json({
    token,
    user: {
      id: user.id, name: user.name, email: user.email,
      phone: user.phone, role: user.role, isVerified: user.isVerified,
      createdAt: user.createdAt,
    },
  });
});

router.post("/auth/register-public", async (req, res): Promise<void> => {
  const {
    name, phone, email, password,
    userType, city, vehicleNumber,
    notificationConsent, locationConsent,
  } = req.body;

  if (!name || !email || !password || !userType || !city) {
    res.status(400).json({ error: "validation_error", message: "All required fields must be provided" });
    return;
  }

  const existing = await db.select().from(usersTable).where(eq(usersTable.email, email)).limit(1);
  if (existing.length > 0) {
    res.status(400).json({ error: "duplicate_user", message: "Email already registered" });
    return;
  }

  const passwordHash = hashPassword(password);
  const [user] = await db.insert(usersTable).values({
    name, phone, email, passwordHash, role: "public", isVerified: true,
  }).returning();

  await db.insert(publicProfilesTable).values({
    userId: user.id, userType: userType || "civilian", city,
    vehicleNumber, notificationConsent: !!notificationConsent,
    locationConsent: !!locationConsent,
  });

  const token = signToken({ id: user.id, role: "public", email: user.email });
  res.status(201).json({
    token,
    user: {
      id: user.id, name: user.name, email: user.email,
      phone: user.phone, role: user.role, isVerified: user.isVerified,
      createdAt: user.createdAt,
    },
  });
});

router.post("/auth/login", async (req, res): Promise<void> => {
  const { email, phone, password, role } = req.body;

  if (!password || !role) {
    res.status(400).json({ error: "validation_error", message: "Password and role are required" });
    return;
  }

  let user;
  if (email) {
    const results = await db.select().from(usersTable).where(eq(usersTable.email, email)).limit(1);
    user = results[0];
  } else if (phone) {
    const results = await db.select().from(usersTable).where(eq(usersTable.phone, phone)).limit(1);
    user = results[0];
  }

  if (!user) {
    res.status(401).json({ error: "invalid_credentials", message: "Invalid credentials" });
    return;
  }

  if (user.role !== role) {
    res.status(401).json({ error: "role_mismatch", message: "Account type does not match" });
    return;
  }

  if (!verifyPassword(password, user.passwordHash)) {
    res.status(401).json({ error: "invalid_credentials", message: "Invalid credentials" });
    return;
  }

  const token = signToken({ id: user.id, role: user.role, email: user.email });
  res.json({
    token,
    user: {
      id: user.id, name: user.name, email: user.email,
      phone: user.phone, role: user.role, isVerified: user.isVerified,
      createdAt: user.createdAt,
    },
  });
});

router.post("/auth/logout", (_req, res): void => {
  res.json({ success: true, message: "Logged out successfully" });
});

router.get("/auth/me", requireAuth, async (req, res): Promise<void> => {
  const results = await db.select().from(usersTable).where(eq(usersTable.id, req.user!.id)).limit(1);
  const user = results[0];
  if (!user) {
    res.status(404).json({ error: "not_found", message: "User not found" });
    return;
  }
  res.json({
    id: user.id, name: user.name, email: user.email,
    phone: user.phone, role: user.role, isVerified: user.isVerified,
    createdAt: user.createdAt,
  });
});

router.post("/auth/send-otp", async (req, res): Promise<void> => {
  const { type, phone, email } = req.body;
  const target = type === "phone" ? phone : email;
  if (!target) {
    res.status(400).json({ error: "validation_error", message: "Target is required" });
    return;
  }

  const otp = generateOtp();
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000);
  await db.insert(otpVerificationsTable).values({ type, target, otp, expiresAt });

  req.log.info({ type, target: target.slice(0, 4) + "***" }, "OTP generated (simulated send)");
  res.json({ success: true, message: `OTP sent to ${type === "phone" ? "phone" : "email"} (demo mode: ${otp})` });
});

router.post("/auth/verify-otp", async (req, res): Promise<void> => {
  const { type, phone, email, otp } = req.body;
  const target = type === "phone" ? phone : email;

  if (!target || !otp) {
    res.status(400).json({ error: "validation_error", message: "Target and OTP are required" });
    return;
  }

  const records = await db
    .select()
    .from(otpVerificationsTable)
    .where(eq(otpVerificationsTable.target, target))
    .orderBy(otpVerificationsTable.createdAt)
    .limit(5);

  const valid = records.find(r => !r.isUsed && r.otp === otp && r.expiresAt > new Date());
  if (!valid) {
    res.status(400).json({ error: "invalid_otp", message: "Invalid or expired OTP" });
    return;
  }

  await db
    .update(otpVerificationsTable)
    .set({ isUsed: true })
    .where(eq(otpVerificationsTable.id, valid.id));

  res.json({ success: true, message: "OTP verified successfully" });
});

export default router;
