import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, driverProfilesTable, liveLocationsTable, usersTable } from "@workspace/db";
import { requireAuth, requireRole } from "../lib/auth";
import { haversineDistance } from "../lib/geo";

const router: IRouter = Router();

router.post("/location/update", requireAuth, requireRole("driver"), async (req, res): Promise<void> => {
  const { latitude, longitude, accuracy, heading, speed } = req.body;

  if (latitude === undefined || longitude === undefined) {
    res.status(400).json({ error: "validation_error", message: "Latitude and longitude required" });
    return;
  }

  const profile = await db
    .select()
    .from(driverProfilesTable)
    .where(eq(driverProfilesTable.userId, req.user!.id))
    .limit(1);

  if (!profile[0]) {
    res.status(404).json({ error: "not_found", message: "Driver profile not found" });
    return;
  }

  await db.insert(liveLocationsTable).values({
    driverId: req.user!.id,
    latitude, longitude, accuracy, heading, speed,
  });

  await db
    .update(driverProfilesTable)
    .set({
      lastKnownLat: latitude.toString(),
      lastKnownLng: longitude.toString(),
      lastLocationUpdate: new Date(),
    })
    .where(eq(driverProfilesTable.userId, req.user!.id));

  res.json({ success: true, message: "Location updated" });
});

router.get("/ambulance/nearby", async (req, res): Promise<void> => {
  const lat = parseFloat(req.query.lat as string);
  const lng = parseFloat(req.query.lng as string);
  const radius = parseFloat((req.query.radius as string) || "5");

  if (isNaN(lat) || isNaN(lng)) {
    res.status(400).json({ error: "validation_error", message: "Valid lat and lng required" });
    return;
  }

  const allProfiles = await db
    .select({
      profile: driverProfilesTable,
      user: usersTable,
    })
    .from(driverProfilesTable)
    .innerJoin(usersTable, eq(usersTable.id, driverProfilesTable.userId))
    .where(eq(driverProfilesTable.isOnline, true));

  const nearby = allProfiles
    .filter(({ profile }) => {
      if (!profile.lastKnownLat || !profile.lastKnownLng) return false;
      const dist = haversineDistance(
        lat, lng,
        parseFloat(profile.lastKnownLat),
        parseFloat(profile.lastKnownLng)
      );
      return dist <= radius;
    })
    .map(({ profile, user }) => ({
      id: profile.id,
      ambulanceNumber: profile.ambulanceNumber,
      driverName: user.name,
      latitude: parseFloat(profile.lastKnownLat!),
      longitude: parseFloat(profile.lastKnownLng!),
      isEmergencyActive: profile.isEmergencyActive,
      distanceKm: haversineDistance(
        lat, lng,
        parseFloat(profile.lastKnownLat!),
        parseFloat(profile.lastKnownLng!)
      ),
      lastUpdate: profile.lastLocationUpdate,
    }))
    .sort((a, b) => a.distanceKm - b.distanceKm);

  res.json({ ambulances: nearby, total: nearby.length });
});

export default router;
