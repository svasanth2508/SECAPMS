import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import ambulanceRouter from "./ambulance";
import locationRouter from "./location";
import publicRouter from "./public";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(ambulanceRouter);
router.use(locationRouter);
router.use(publicRouter);

export default router;
