import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, usersTable, driverProfilesTable, emergencySessionsTable, liveLocationsTable, notificationsTable } from "@workspace/db";
import { requireAuth, requireRole } from "../lib/auth";

const router: IRouter = Router();

router.get("/ambulance/status", requireAuth, requireRole("driver"), async (req, res): Promise<void> => {
  const profile = await db
    .select()
    .from(driverProfilesTable)
    .where(eq(driverProfilesTable.userId, req.user!.id))
    .limit(1);

  if (!profile[0]) {
    res.status(404).json({ error: "not_found", message: "Driver profile not found" });
    return;
  }

  const user = await db.select().from(usersTable).where(eq(usersTable.id, req.user!.id)).limit(1);

  res.json({
    driverId: profile[0].id,
    name: user[0]?.name || "",
    ambulanceNumber: profile[0].ambulanceNumber,
    isOnDuty: profile[0].isOnDuty,
    isOnline: profile[0].isOnline,
    isEmergencyActive: profile[0].isEmergencyActive,
    lastLocationUpdate: profile[0].lastLocationUpdate,
    nearbyUsersCount: 0,
    latitude: profile[0].lastKnownLat ? parseFloat(profile[0].lastKnownLat) : undefined,
    longitude: profile[0].lastKnownLng ? parseFloat(profile[0].lastKnownLng) : undefined,
  });
});

router.post("/ambulance/duty", requireAuth, requireRole("driver"), async (req, res): Promise<void> => {
  const { action } = req.body;
  const profile = await db
    .select()
    .from(driverProfilesTable)
    .where(eq(driverProfilesTable.userId, req.user!.id))
    .limit(1);

  if (!profile[0]) {
    res.status(404).json({ error: "not_found", message: "Driver profile not found" });
    return;
  }

  const updates: Partial<{ isOnDuty: boolean; isOnline: boolean }> = {};
  if (action === "start_duty") updates.isOnDuty = true;
  if (action === "end_duty") { updates.isOnDuty = false; updates.isOnline = false; }
  if (action === "go_online") updates.isOnline = true;
  if (action === "go_offline") updates.isOnline = false;

  const [updated] = await db
    .update(driverProfilesTable)
    .set(updates)
    .where(eq(driverProfilesTable.userId, req.user!.id))
    .returning();

  const user = await db.select().from(usersTable).where(eq(usersTable.id, req.user!.id)).limit(1);

  res.json({
    driverId: updated.id,
    name: user[0]?.name || "",
    ambulanceNumber: updated.ambulanceNumber,
    isOnDuty: updated.isOnDuty,
    isOnline: updated.isOnline,
    isEmergencyActive: updated.isEmergencyActive,
    lastLocationUpdate: updated.lastLocationUpdate,
    nearbyUsersCount: 0,
  });
});

router.post("/ambulance/start-emergency", requireAuth, requireRole("driver"), async (req, res): Promise<void> => {
  const { message, latitude, longitude } = req.body;

  const profile = await db
    .select()
    .from(driverProfilesTable)
    .where(eq(driverProfilesTable.userId, req.user!.id))
    .limit(1);

  if (!profile[0]) {
    res.status(404).json({ error: "not_found", message: "Driver profile not found" });
    return;
  }

  await db
    .update(driverProfilesTable)
    .set({ isEmergencyActive: true, isOnline: true, isOnDuty: true })
    .where(eq(driverProfilesTable.userId, req.user!.id));

  const [session] = await db
    .insert(emergencySessionsTable)
    .values({
      driverId: req.user!.id,
      driverProfileId: profile[0].id,
      startLat: latitude?.toString(),
      startLng: longitude?.toString(),
      message: message || "Emergency ambulance approaching. Please give way. / அவசரவாகனம் வருகிறது. வழி விடுங்கள்.",
      isActive: true,
      notifiedUsersCount: 0,
    })
    .returning();

  res.json({
    sessionId: session.id,
    driverId: req.user!.id,
    startedAt: session.startedAt,
    message: session.message,
    isActive: session.isActive,
    notifiedUsersCount: session.notifiedUsersCount,
  });
});

router.post("/ambulance/stop-emergency", requireAuth, requireRole("driver"), async (req, res): Promise<void> => {
  await db
    .update(driverProfilesTable)
    .set({ isEmergencyActive: false })
    .where(eq(driverProfilesTable.userId, req.user!.id));

  await db
    .update(emergencySessionsTable)
    .set({ isActive: false, endedAt: new Date() })
    .where(eq(emergencySessionsTable.driverId, req.user!.id));

  res.json({ success: true, message: "Emergency stopped" });
});

router.get("/ambulance/alert-history", requireAuth, requireRole("driver"), async (req, res): Promise<void> => {
  const profile = await db
    .select()
    .from(driverProfilesTable)
    .where(eq(driverProfilesTable.userId, req.user!.id))
    .limit(1);

  if (!profile[0]) {
    res.json({ history: [], total: 0 });
    return;
  }

  const sessions = await db
    .select()
    .from(emergencySessionsTable)
    .where(eq(emergencySessionsTable.driverProfileId, profile[0].id))
    .orderBy(desc(emergencySessionsTable.startedAt))
    .limit(20);

  const history = sessions.map(s => ({
    id: s.id,
    startedAt: s.startedAt,
    endedAt: s.endedAt,
    message: s.message,
    notifiedCount: s.notifiedUsersCount,
    durationMinutes: s.endedAt
      ? Math.round((s.endedAt.getTime() - s.startedAt.getTime()) / 60000)
      : undefined,
  }));

  res.json({ history, total: history.length });
});

export default router;
