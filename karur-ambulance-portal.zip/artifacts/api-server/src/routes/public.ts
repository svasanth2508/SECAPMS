import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, emergencySessionsTable, notificationsTable, usersTable, driverProfilesTable } from "@workspace/db";
import { requireAuth, requireRole } from "../lib/auth";

const router: IRouter = Router();

router.get("/public/active-alerts", requireAuth, async (req, res): Promise<void> => {
  const sessions = await db
    .select({
      session: emergencySessionsTable,
      profile: driverProfilesTable,
      user: usersTable,
    })
    .from(emergencySessionsTable)
    .innerJoin(driverProfilesTable, eq(driverProfilesTable.id, emergencySessionsTable.driverProfileId))
    .innerJoin(usersTable, eq(usersTable.id, emergencySessionsTable.driverId))
    .where(eq(emergencySessionsTable.isActive, true))
    .orderBy(desc(emergencySessionsTable.startedAt))
    .limit(10);

  const alerts = sessions.map(({ session, profile, user }) => ({
    id: session.id,
    ambulanceId: profile.id,
    ambulanceNumber: profile.ambulanceNumber,
    driverName: user.name,
    message: session.message || "Emergency ambulance approaching. Please give way.",
    latitude: profile.lastKnownLat ? parseFloat(profile.lastKnownLat) : parseFloat(session.startLat || "10.957"),
    longitude: profile.lastKnownLng ? parseFloat(profile.lastKnownLng) : parseFloat(session.startLng || "78.082"),
    distanceKm: 0,
    startedAt: session.startedAt,
    isActive: session.isActive,
  }));

  res.json({ alerts, total: alerts.length });
});

router.get("/public/notification-history", requireAuth, requireRole("public"), async (req, res): Promise<void> => {
  const notifications = await db
    .select()
    .from(notificationsTable)
    .where(eq(notificationsTable.userId, req.user!.id))
    .orderBy(desc(notificationsTable.createdAt))
    .limit(50);

  const items = notifications.map(n => ({
    id: n.id,
    title: n.title,
    body: n.body,
    type: n.type,
    createdAt: n.createdAt,
    isRead: n.isRead,
  }));

  res.json({ notifications: items, total: items.length });
});

router.post("/notifications/register-token", requireAuth, async (req, res): Promise<void> => {
  const { token } = req.body;
  if (!token) {
    res.status(400).json({ error: "validation_error", message: "FCM token required" });
    return;
  }
  await db.update(usersTable).set({ fcmToken: token }).where(eq(usersTable.id, req.user!.id));
  res.json({ success: true, message: "Token registered" });
});

export default router;
