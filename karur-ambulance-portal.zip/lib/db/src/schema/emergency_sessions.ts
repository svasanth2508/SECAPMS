import { pgTable, text, serial, timestamp, boolean, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const emergencySessionsTable = pgTable("emergency_sessions", {
  id: serial("id").primaryKey(),
  driverId: integer("driver_id").notNull(),
  driverProfileId: integer("driver_profile_id").notNull(),
  startLat: text("start_lat"),
  startLng: text("start_lng"),
  message: text("message"),
  isActive: boolean("is_active").notNull().default(true),
  notifiedUsersCount: integer("notified_users_count").notNull().default(0),
  startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
  endedAt: timestamp("ended_at", { withTimezone: true }),
});

export const insertEmergencySessionSchema = createInsertSchema(emergencySessionsTable).omit({ id: true, startedAt: true });
export type InsertEmergencySession = z.infer<typeof insertEmergencySessionSchema>;
export type EmergencySession = typeof emergencySessionsTable.$inferSelect;
