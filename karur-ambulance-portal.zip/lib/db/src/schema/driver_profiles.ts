import { pgTable, text, serial, timestamp, boolean, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const driverProfilesTable = pgTable("driver_profiles", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  ambulanceNumber: text("ambulance_number").notNull(),
  licenseNumber: text("license_number").notNull(),
  govtId: text("govt_id").notNull(),
  serviceType: text("service_type").notNull(),
  hospitalName: text("hospital_name").notNull(),
  baseLocation: text("base_location").notNull(),
  emergencyContact: text("emergency_contact").notNull(),
  isOnDuty: boolean("is_on_duty").notNull().default(false),
  isOnline: boolean("is_online").notNull().default(false),
  isEmergencyActive: boolean("is_emergency_active").notNull().default(false),
  lastKnownLat: text("last_known_lat"),
  lastKnownLng: text("last_known_lng"),
  lastLocationUpdate: timestamp("last_location_update", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertDriverProfileSchema = createInsertSchema(driverProfilesTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertDriverProfile = z.infer<typeof insertDriverProfileSchema>;
export type DriverProfile = typeof driverProfilesTable.$inferSelect;
