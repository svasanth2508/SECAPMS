import { pgTable, text, serial, timestamp, boolean, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const publicProfilesTable = pgTable("public_profiles", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  userType: text("user_type").notNull().default("civilian"),
  city: text("city").notNull(),
  vehicleNumber: text("vehicle_number"),
  notificationConsent: boolean("notification_consent").notNull().default(false),
  locationConsent: boolean("location_consent").notNull().default(false),
  soundAlertsEnabled: boolean("sound_alerts_enabled").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertPublicProfileSchema = createInsertSchema(publicProfilesTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertPublicProfile = z.infer<typeof insertPublicProfileSchema>;
export type PublicProfile = typeof publicProfilesTable.$inferSelect;
