# Karur Ambulance Emergency Portal

## Overview

A full-stack bilingual (English + Tamil) emergency ambulance portal for Karur, Tamil Nadu, India. It has two separate role-based portals: one for Ambulance Drivers and one for the general Public.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **Frontend**: React + Vite + Tailwind CSS
- **Backend**: Express 5 (Node.js)
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Forms**: React Hook Form + Zod
- **Animation**: Framer Motion
- **Build**: esbuild (backend), Vite (frontend)

## Bilingual Support (English + Tamil)

All UI text supports two languages via a `LanguageContext` and `useLanguage` hook:
- Translation dictionary: `artifacts/karur-portal/src/lib/i18n.ts`
- Language context: `artifacts/karur-portal/src/contexts/language-context.tsx`
- Language toggle component: `artifacts/karur-portal/src/components/layout/language-toggle.tsx`
- Toggle persists to `localStorage` as `karur_language`

## Structure

```text
artifacts-monorepo/
├── artifacts/
│   ├── karur-portal/     # React + Vite frontend (served at /)
│   └── api-server/       # Express 5 API server (served at /api)
├── lib/
│   ├── api-spec/         # OpenAPI spec + Orval codegen config
│   ├── api-client-react/ # Generated React Query hooks
│   ├── api-zod/          # Generated Zod schemas
│   └── db/               # Drizzle ORM schema + DB connection
├── scripts/              # Utility scripts
```

## Frontend Pages

- `/` — Landing page with portal selection
- `/ambulance/login` — Ambulance driver login (bilingual)
- `/ambulance/register` — Ambulance driver registration
- `/ambulance/dashboard` — Driver dashboard (duty status, emergency controls, bilingual)
- `/public/login` — Public user login
- `/public/register` — Public user registration
- `/public/dashboard` — Public dashboard (alert banner, ambulance tracking, bilingual)

## Backend Routes (all under /api)

- `POST /api/auth/register-driver` — Register ambulance driver
- `POST /api/auth/register-public` — Register public user
- `POST /api/auth/login` — Login (driver or public)
- `POST /api/auth/logout` — Logout
- `GET /api/auth/me` — Get current user
- `POST /api/auth/send-otp` — Send OTP
- `POST /api/auth/verify-otp` — Verify OTP
- `GET /api/ambulance/status` — Get driver status
- `POST /api/ambulance/duty` — Update duty/online status
- `POST /api/ambulance/start-emergency` — Start emergency broadcast
- `POST /api/ambulance/stop-emergency` — Stop emergency
- `GET /api/ambulance/alert-history` — Alert session history
- `GET /api/ambulance/nearby` — Get nearby ambulances
- `POST /api/location/update` — Update driver GPS location
- `GET /api/public/active-alerts` — Get active emergency alerts
- `GET /api/public/notification-history` — Notification history
- `POST /api/notifications/register-token` — Register FCM token

## Database Schema

Tables: `users`, `driver_profiles`, `public_profiles`, `emergency_sessions`, `live_locations`, `otp_verifications`, `notifications`

## Auth

- JWT-based auth using HMAC-SHA256 (no external library)
- Tokens stored in `localStorage` as `karur_auth_token`
- Role-based route guards on frontend (driver vs public)
- Role-based middleware on backend (`requireAuth`, `requireRole`)

## Environment Variables

- `DATABASE_URL` — PostgreSQL connection string (auto-provisioned by Replit)
- `PORT` — Server port (auto-assigned by Replit)
- `JWT_SECRET` — JWT signing secret (optional, has development fallback)

## Running Codegen

After changing `lib/api-spec/openapi.yaml`:
```bash
pnpm --filter @workspace/api-spec run codegen
```

## Pushing DB Schema

```bash
pnpm --filter @workspace/db run push
```
